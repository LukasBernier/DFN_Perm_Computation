/*

 * DisplayResults.h
 *
 *  Created on: Apr 22, 2013
 *      Author: delphineroubinet*/


#ifndef DISPLAYRESULTS_H_
#define DISPLAYRESULTS_H_

#include <iostream>
#include "VisuStructures.h"


class DisplayResults {
private:
	DFNVisu results;
	EPMVisu results2;
	EPMDFNVisu res_EPMDFN;
public:
	DisplayResults();
	virtual ~DisplayResults();
	//DisplayResults(int,char **,DFNVisu,std::string option1="DFN",std::string option2="classic");
	DisplayResults(int,char **,DFNVisu);
	DisplayResults(int,char **,EPMVisu,std::string option="Potential") ;
	DisplayResults(int,char **,EPMDFNVisu,std::string option=DEFAULT);
};



#endif // DISPLAYRESULTS_H_

