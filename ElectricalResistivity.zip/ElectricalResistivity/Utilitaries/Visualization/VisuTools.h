/*

 * VisuTools.h
 *
 *  Created on: Apr 22, 2013
 *      Author: delphineroubinet*/


#ifndef VISUTOOLS_H_
#define VISUTOOLS_H_

void SetColor(double);
void SetColor(double,double,double);
bool draw_legend_scale(double,double,double,double,int,int,double);

#endif // VISUTOOLS_H_

