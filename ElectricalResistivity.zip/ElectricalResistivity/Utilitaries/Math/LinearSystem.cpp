/*
 * LinearSystem.cpp
 *
 *  Created on: Apr 22, 2013
 *      Author: delphineroubinet
 */

#include "LinearSystem.h"

#include <iostream>
#include <boost/numeric/bindings/traits/ublas_vector.hpp>
#include <boost/numeric/bindings/traits/ublas_sparse.hpp>
#include <boost/numeric/bindings/umfpack/umfpack.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <Eigen/IterativeLinearSolvers>
#include<Eigen/SparseLU>
#include<Eigen/SparseQR>
#include<Eigen/SparseCholesky>

namespace ublas = boost::numeric::ublas;
namespace umf = boost::numeric::bindings::umfpack;
using namespace std;

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::Lower;
using Eigen::Upper;
using Eigen::SparseMatrix;
using Eigen::ConjugateGradient;
using Eigen::IdentityPreconditioner;

typedef Eigen::Triplet<double> T;

//typedef boost::numeric::ublas::compressed_matrix<double, boost::numeric::ublas::column_major, 0,boost::numeric::ublas::unbounded_array<int>, boost::numeric::ublas::unbounded_array<double> > ublas_matrix_syst;
typedef boost::numeric::ublas::compressed_matrix<double, boost::numeric::ublas::column_major, 0,boost::numeric::ublas::unbounded_array<int>, boost::numeric::ublas::unbounded_array<double> >::iterator1 it1_ublas_mat;typedef boost::numeric::ublas::compressed_matrix<double, boost::numeric::ublas::column_major, 0,boost::numeric::ublas::unbounded_array<int>, boost::numeric::ublas::unbounded_array<double> >::iterator2 it2_ublas_mat;
//typedef boost::numeric::ublas::compressed_matrix<double>::iterator1 it1_ublas_mat;
//typedef boost::numeric::ublas::compressed_matrix<double>::iterator2 it2_ublas_mat;

// return the solution x of the linear system Ax = b (A = mat_syst, b = vect_syst and x = vect_sol)
ublas_vector LinearSystemSolving(ublas_matrix mat_syst, ublas_vector vect_syst,int option){

	// 0. Variables definition
        int Ny = vect_syst.size();
        ublas::vector<double> X(Ny);
	// 1. System checking
	if ((unsigned)mat_syst.size2()!=vect_syst.size()){cout << "WARNING in LinearSystemSolving (LinearSystemUtilitaries.cpp): system not well defined" << endl;return X;}
	// 2. Solving the linear system
	// 2.1. Option with direct solving method
	if (option==0){
		umf::symbolic_type<double> Symbolic;
                umf::numeric_type<double> Numeric;
                umf::symbolic (mat_syst, Symbolic);
                umf::numeric (mat_syst, Symbolic, Numeric);
                umf::solve (mat_syst, X, vect_syst, Numeric);
	}
	// 2.2. Option with iterative method - conjugate gradient
	else if (option==1){
    		int n = vect_syst.size();
    		VectorXd b(n),x;
    		SparseMatrix<double> A(n,n);
		// fill A and b
		std::vector<T> coefficients;
		for (int i=0;i<n;i++){
                	for (int j=0;j<n;j++){
				coefficients.push_back(T(i,j,mat_syst(i,j)));
			}
		}
		A.setFromTriplets(coefficients.begin(), coefficients.end());
		for (int i=0;i<n;i++){
			b(i)=vect_syst(i);
		}
		// Linear system method
    		ConjugateGradient<SparseMatrix<double>, Lower|Upper,IdentityPreconditioner> cg;
    		cg.compute(A);
   		x=cg.solve(b);
		cout << "tolerance = " << cg.tolerance() << endl;
	        cout << "max iterations:     " << cg.maxIterations() << endl; 
    		cout << "#iterations:     " << cg.iterations() << endl;
    		cout << "estimated error: " << cg.error()      << endl;
		if (cg.info()==Eigen::Success){cout << "computation successful" << endl;}
		else{cout << "computation failed" << endl;}
		//cout << x << endl;
		for (int i=0;i<vect_syst.size();i++){
                        X(i)=x(i);
                }
	}
	// 2.3. Direct solver with LU decomposition
	else if (option==2){
		int n = vect_syst.size();
                VectorXd b(n),x;
		SparseMatrix<double> A(n,n);
		//Eigen::SparseLU<SparseMatrix<double>, Eigen::COLAMDOrdering<int> >   solver;
		Eigen::SparseQR<SparseMatrix<double>, Eigen::COLAMDOrdering<int> >   solver;
		// fill A and b;
		std::vector<T> coefficients;
                for (int i=0;i<n;i++){
                        for (int j=0;j<n;j++){
                                coefficients.push_back(T(i,j,mat_syst(i,j)));
                        }
                }
                A.setFromTriplets(coefficients.begin(), coefficients.end());
                for (int i=0;i<n;i++){
                        b(i)=vect_syst(i);
                }
		// Compute the ordering permutation vector from the structural pattern of A
		solver.analyzePattern(A); 
		// Compute the numerical factorization 
		solver.factorize(A); 
		// Use the factors to solve the linear system 
		x = solver.solve(b);
                if (solver.info()==Eigen::Success){cout << "computation successful" << endl;}
                else{cout << "computation failed" << endl;}
 		for (int i=0;i<vect_syst.size();i++){X(i)=x(i);}
	}
	else if (option==3){
                int n = vect_syst.size();
                VectorXd b(n),x;
                SparseMatrix<double> A(n,n);
                //Eigen::SimplicialLLT<SparseMatrix<double>,Eigen::Lower,Eigen::AMDOrdering<int> >   solver;
		Eigen::SimplicialLDLT<SparseMatrix<double>,Eigen::Lower,Eigen::AMDOrdering<int> >   solver;
                // fill A and b;
                std::vector<T> coefficients;
                for (int i=0;i<n;i++){
                	for (int j=0;j<n;j++){
                	        coefficients.push_back(T(i,j,mat_syst(i,j)));
                	}
		}
                A.setFromTriplets(coefficients.begin(), coefficients.end());
                for (int i=0;i<n;i++){b(i)=vect_syst(i);}
                // Compute the ordering permutation vector from the structural pattern of A
                solver.analyzePattern(A);
                // Compute the numerical factorization 
                solver.factorize(A);
                // Use the factors to solve the linear system 
                x = solver.solve(b);
                if (solver.info()==Eigen::Success){cout << "computation successful" << endl;}
                else{cout << "computation failed" << endl;}
                for (int i=0;i<vect_syst.size();i++){X(i)=x(i);}
	}
	return X;
}



